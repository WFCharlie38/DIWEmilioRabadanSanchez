# 01 - Navbar base (lista de enlaces)

**Objetivo:** construir una barra de navegación a partir de una lista sin viñetas.

## Requisitos
- `<nav>` con `<ul><li><a>`
- Quitar `list-style`, márgenes y padding por defecto
- Tipografía legible, foco visible

