# 02 - Navbar horizontal

**Objetivo:** disponer la barra en horizontal con estados hover/focus.

## Requisitos
- Enlaces en fila (flex o inline-block)
- Estados `:hover` y `:focus` visibles
- Contraste AA


