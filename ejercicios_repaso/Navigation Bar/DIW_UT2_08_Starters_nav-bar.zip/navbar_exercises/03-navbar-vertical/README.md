# 03 - Navbar vertical (sidebar)

**Objetivo:** versión vertical ocupando la altura del viewport.

## Requisitos
- Sidebar de 100vh
- Enlace activo destacado


