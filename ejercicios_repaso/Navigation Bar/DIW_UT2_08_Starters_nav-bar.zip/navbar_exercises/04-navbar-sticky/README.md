# 04 - Navbar fija (sticky/top)

**Objetivo:** mantener la barra visible al hacer scroll.

## Requisitos
- `position: sticky` (o `fixed`) + `top:0`
- Evitar solapados con el contenido
