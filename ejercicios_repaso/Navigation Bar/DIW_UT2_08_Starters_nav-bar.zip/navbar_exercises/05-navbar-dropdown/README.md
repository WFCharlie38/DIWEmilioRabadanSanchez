# 05 - Dropdown básico (solo CSS)

**Objetivo:** submenús accesibles con `:hover` y `:focus-within`.

## Requisitos
- Submenú anidado
- Accesible con teclado
