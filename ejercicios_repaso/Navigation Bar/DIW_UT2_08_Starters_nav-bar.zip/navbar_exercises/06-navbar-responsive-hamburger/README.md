# 06 - Responsive (hamburguesa sin JS)

**Objetivo:** colapsar la nav en móvil usando checkbox + label.

## Requisitos
- `<input type="checkbox">` oculto y `<label>` como botón
- Media queries para mostrar/ocultar
