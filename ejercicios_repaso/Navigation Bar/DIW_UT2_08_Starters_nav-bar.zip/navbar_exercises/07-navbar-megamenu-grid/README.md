# 07 - Megamenú (Grid)

**Objetivo:** desplegable amplio con 2–3 columnas usando CSS Grid.

## Requisitos
- Submenú en grid (columnas con títulos)
- Accesible con teclado
