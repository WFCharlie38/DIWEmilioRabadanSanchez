# 08 - Theming con variables CSS

**Objetivo:** mismo HTML, dos temas (claro/oscuro) sustituyendo variables.

## Requisitos
- Variables en `:root`
- Modo `.dark` alternativo (checkbox hack opcional)
